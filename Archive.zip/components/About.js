import React,{Component} from 'react';
import {View,Text,StyleSheet} from 'react-native';
import axios from 'axios';
import { parseString } from "react-native-xml2js";
const API_URL = 'https://api.themoviedb.org/3'


//https://api.themoviedb.org/3/movie/550?api_key=53de4458f25a1566019724d90a1138f5

export default class About extends Component
{
  constructor(props) {
      super(props);
      this.state = {
        isLoading: true,
        dataSource: [],
        movies: []
     }
    }




    
  componentDidMount()
  {

    fetch("https://api.themoviedb.org/3/movie/550?api_key=53de4458f25a1566019724d90a1138f5")
    
    .then((response) => response.json())
    
    .then((responseJson) => {

    
    
    this.setState({ movies: responseJson });
    
    }).catch((error) => {
    
    console.log("Data fetching failed");
    
    });
    

//     return fetch('https://facebook.github.io/react-native/movies.json')
//     .then((response) => response.json())
//     .then((responseJson)=>{

//       this.setState({
//         isLoading: false,
//         dataSource: responseJson.movies,
//       }),
//       console.log(responseJson);
//     }

//   )
//     .catch((error) =>
//     {
// console.log(error)

// });

  }

  fetchMovies() {
   
    fetch("https://api.themoviedb.org/3/movie/550?api_key=53de4458f25a1566019724d90a1138f5")
    
    .then((response) => response.json())
    
    .then((responseJson) => {

    
    
    this.setState({ movies: responseJson });
    
    }).catch((error) => {
    
    console.log("Data fetching failed");
    
    });
    
    }

//   render() 
//   {
// let movies = this.state.dataSource.map((val,key) => {
// return <View key={key} style={styles.item}>
// <Text>{val.title}</Text>
// </View>

// });

//     return (
//       <View style={styles.container}>
//           <Text>{movies}</Text>
//         </View>
//     );
//   }


render() {

  const {movies} = this.state
  
  return (
  
  <View style={styles.container}>
  <Text>kkk</Text>
  {movies && movies.results && movies.results.length>0? (<FlatList
  
  data={movies.results}
  
  renderItem={({ item }) => <MyMovieItem item={item} />}
  
  keyExtractor={(item,key) => key}
  
  //onRefresh={this.onRefresh}
  
  //refreshing={this.state.refreshing}
  
  ></FlatList>) : null}
  
  </View>
  
  );
  
  }

}

const styles = StyleSheet.create({

  container: {
  
  flex: 1,
  
  justifyContent: 'center',
  
  paddingTop: 1,
  
  backgroundColor: '#ecf0f1',
  
  padding: 8,
  
  },
  
  });
