import React,{Component} from 'react';
import {View,Text,FlatList,Button} from 'react-native';
import { ListItem } from "react-native-elements"

export default class Playlist extends Component
{

    constructor() {
        super();
    
        this.state = {
          dataSource: [{key:1, name:'const abc item'}, {key:2, name:'const def item'}],
        };
        this.getRemoteData();
      }

      capFirstLetter = (string) => {
        return string.charAt(0).toUpperCase() + string.slice(1);
      }
      renderNativeItem = (item) => {
        const name = this.capFirstLetter(item.name.title) + ". " 
          + this.capFirstLetter(item.name.first) + " " 
          + this.capFirstLetter(item.name.last);
        return <ListItem
                roundAvatar
                title={name}
                subtitle={item.email}
                avatar={{ uri: item.picture.thumbnail }}
                onPress={() => this.onPressItem(item)}
              />;
      }
    
      onPressItem = (item) => {
        const email = item.email;
        console.log("onPress email with item: " + item.email);
        this.props.navigation.navigate('Detail', {item: item})
      }

// render()
// {

// return (

// <View style = {{flex:1,justifyContent:'center',alignItems:'center'}}>
// <Text>play-aa</Text>
// </View>

// );

// }

render() {
    return (
      <View>
        <FlatList
          data={this.state.data}
          renderItem={({item}) => this.renderNativeItem(item)}
        />
        <Button
          title="Go Detail"
          onPress={() => this.props.navigation.navigate('Detail', {source: "homescreen"})}
        />
      </View>
    );
  }




getRemoteData = () => {
    const url = "https://randomuser.me/api/?results=10";
    fetch(url)
      .then(res => res.json())
      .then(res => {
        this.setState({
          data: res.results
        });
      })
      .catch(error => {
        console.log("get data error:" + error);
      });
  }

}
