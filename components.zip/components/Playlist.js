import React,{Component} from 'react';
import {View,Text,FlatList,Button,Image} from 'react-native';
import { ListItem } from "react-native-elements"
import { parse } from 'fast-xml-parser';
export default class Playlist extends Component
{

    constructor() {
        super();
    
        this.state = {
          dataSource: [{key:1, name:'const abc item'}, {key:2, name:'const def item'}],
          data:[]
        };
        this.getRemoteData();
      }

     


render() {
//console.log("===============");
//console.log(this.state.data);

 // console.log(this.state.data);
    return (
      <View>
        <FlatList
          data={this.state.data}
          renderItem={({item}) => 

          <View>

    <Text>{item.title._text}</Text>
<Image
source={{ uri: item.cover._text}}
style={{ width: 40, height: 40, margin: 6 }}
/>

          </View>
  
        }
          
        />
        <Button
          title="Go Detail"
          onPress={() => this.props.navigation.navigate('Detail', {source: "homescreen"})}
        />
      </View>
    );
  }




getRemoteData = () => 


{
    // const url = "https://streamdb9web.securenetsystems.net/player_status_update/REVRADIO_history.xml";
    // fetch(url)
    //   .then(res => {
    //     this.setState({
    //       data: res.results
    //     });
    //     console.log(res.results);
    //   })
    //   .catch(error => {
    //     console.log("get data error:" + error);
    //   });




//     const axios = require('axios');
 
// // Make a request for a user with a given ID
// axios.get('https://streamdb9web.securenetsystems.net/player_status_update/REVRADIO_history.xml')
//   .then(function (response) 
//   {
//     // handle success
//     console.log(response);
//   })
//   .catch(function (error) {
//     // handle error
//     console.log(error);
//   })
//   .then(function () {
//     // always executed
//   });


fetch('https://streamdb9web.securenetsystems.net/player_status_update/REVRADIO_history.xml')
.then((response) => response.text())
.then((textResponse) => {
  //console.log(textResponse);
    let obj = parse(textResponse);

    var convert = require('xml-js');
    var xml = textResponse
    var result1 = convert.xml2js(xml, {compact: true, spaces: 1});



    console.log(result1.playHistory.song);




   // var result2 = convert.xml2json(xml, {compact: false, spaces: 4});
   //var obj = JSON.parse(result1);
//console.log("result1----"+result1);
   // console.log("result2----"+result2);
//console.log(JSON.parse(result1));
//var ddd = JSON.parse(result1.song);
//console.log(ddd);

    this.setState({ data: result1.playHistory.song})
})
.catch((error) => {
    console.log(error);
});

  }

}
